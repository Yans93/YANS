/* ============ CONFIGURATION : à compléter avant publication ============ */
const CONFIG = { email: null, instagram: null }; // ex. { email:"contact@votre-domaine.fr", instagram:"https://instagram.com/votrecompte" }
const LEGAL = {
  responsable: null,      // Nom et prénom du responsable
  statut: null,           // Statut juridique
  adresse: null,          // Adresse professionnelle
  siret: null,            // Numéro SIRET si applicable
  tva: null,              // Régime de TVA
  directeur: null,        // Directeur de publication
  hebergeur: null,        // Nom de l'hébergeur
  hebergeurAdresse: null, // Adresse de l'hébergeur
  hebergeurContact: null, // Téléphone / e-mail de l'hébergeur
  mediateur: null         // Médiateur de la consommation
};
/* ======================================================================= */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const TODO = '<mark class="todo">À COMPLÉTER</mark>';
const f = k => LEGAL[k] ? esc(LEGAL[k]) : TODO;
const mail = () => CONFIG.email ? `<a href="mailto:${esc(CONFIG.email)}">${esc(CONFIG.email)}</a>` : TODO;

/* Coordonnées (emplacements) */
(function(){
  const e = CONFIG.email, i = CONFIG.instagram;
  $('#slot-email').innerHTML = e ? `<a href="mailto:${esc(e)}">${esc(e)}</a>` : '<span class="empty">Adresse e-mail à compléter</span>';
  $('#slot-insta').innerHTML = i ? `<a href="${esc(i)}" target="_blank" rel="noopener">${esc(i.replace(/^https?:\/\//,''))}</a>` : '<span class="empty">Compte Instagram à compléter</span>';
  $('#ft-email').innerHTML = e ? `<a href="mailto:${esc(e)}">${esc(e)}</a>` : '<span class="todo-i">E-mail à compléter</span>';
  $('#ft-insta').innerHTML = i ? `<a href="${esc(i)}" target="_blank" rel="noopener">Instagram</a>` : '<span class="todo-i">Instagram à compléter</span>';
})();

/* Menu mobile */
const burger = $('#burger'), nav = $('#nav');
const setMenu = open => { nav.classList.toggle('open', open); burger.setAttribute('aria-expanded', open); burger.setAttribute('aria-label', open ? 'Fermer le menu' : 'Ouvrir le menu'); };
burger.addEventListener('click', () => setMenu(!nav.classList.contains('open')));
nav.addEventListener('click', e => { if (e.target.closest('a')) setMenu(false); });

/* Pages légales */
const DRAFT = `<div class="draft"><strong>Modèle à vérifier et à compléter.</strong> Ce texte n'est pas juridiquement validé. Les champs marqués ${TODO} doivent être renseignés, et l'ensemble relu par un professionnel du droit avant la mise en ligne.</div>`;
const PAGES = {
  'mentions-legales': { t: 'Mentions légales', h: () => `
    <h2>Éditeur du site</h2>
    <ul><li>Nom commercial : YANS</li><li>Responsable : ${f('responsable')}</li><li>Statut juridique : ${f('statut')}</li><li>Adresse professionnelle : ${f('adresse')}</li><li>E-mail : ${mail()}</li><li>Numéro SIRET (si applicable) : ${f('siret')}</li><li>Régime de TVA : ${f('tva')}</li></ul>
    <h2>Directeur de la publication</h2><p>${f('directeur')}</p>
    <h2>Hébergeur du site</h2>
    <ul><li>Nom : ${f('hebergeur')}</li><li>Adresse : ${f('hebergeurAdresse')}</li><li>Contact : ${f('hebergeurContact')}</li></ul>
    <h2>Propriété intellectuelle</h2><p>Les textes, visuels, logos, maquettes et éléments graphiques du site sont la propriété de YANS ou utilisés avec l'autorisation de leurs titulaires. Toute reproduction ou réutilisation sans accord écrit préalable est interdite.</p>
    <h2>Démonstrations</h2><p>Les maquettes présentées dans la section « Portfolio » sont des démonstrations fictives. Elles ne représentent pas des réalisations pour de vrais clients.</p>
    <h2>Données personnelles et cookies</h2><p>Voir la <a href="#confidentialite">politique de confidentialité</a> et la <a href="#cookies">politique relative aux cookies</a>.</p>` },
  'confidentialite': { t: 'Politique de confidentialité', h: () => `
    <h2>Responsable du traitement</h2><p>YANS, représenté par ${f('responsable')}, ${f('adresse')}. Contact : ${mail()}.</p>
    <h2>Données collectées</h2><p>Lorsque vous utilisez le formulaire de contact, nous collectons les informations que vous saisissez :</p>
    <ul><li>nom et prénom ;</li><li>adresse e-mail ;</li><li>offre souhaitée ;</li><li>description de votre projet.</li></ul>
    <p>Aucune autre donnée n'est demandée. Les champs ne sont pas utilisés pour de la prospection sans votre accord.</p>
    <h2>Finalités et bases légales</h2>
    <ul><li>Répondre à votre demande et établir un devis (mesures précontractuelles prises à votre demande).</li><li>Gérer la relation commerciale en cas de commande (exécution du contrat).</li><li>Conserver les preuves et documents comptables (obligation légale).</li></ul>
    <h2>Durée de conservation</h2>
    <ul><li>Demande sans suite : 3 ans maximum à compter du dernier contact (durée usuelle, à confirmer).</li><li>Client : durée de la relation contractuelle, puis conservation des pièces comptables selon les délais légaux.</li></ul>
    <h2>Destinataires</h2><p>Vos données sont destinées à YANS. Elles peuvent être traitées par des prestataires techniques (hébergement du site, service d'envoi des formulaires) : ${TODO}. Si un prestataire est situé hors de l'Union européenne, les garanties de transfert doivent être indiquées ici : ${TODO}.</p>
    <h2>Vos droits</h2><p>Vous disposez des droits d'accès, de rectification, d'effacement, d'opposition, de limitation et de portabilité. Pour les exercer, écrivez à ${mail()}. Vous pouvez aussi introduire une réclamation auprès de la CNIL (cnil.fr).</p>
    <h2>Sécurité</h2><p>Nous prenons des mesures raisonnables pour protéger vos données contre l'accès non autorisé, la perte ou l'altération. ${TODO}</p>
    <h2>Cookies</h2><p>Voir la <a href="#cookies">politique relative aux cookies</a>.</p>` },
  'cookies': { t: 'Politique relative aux cookies', h: () => `
    <h2>Qu'est-ce qu'un cookie ?</h2><p>Un cookie est un petit fichier enregistré sur votre appareil lors de la visite d'un site. Certains sont nécessaires au fonctionnement du site, d'autres servent à mesurer l'audience ou à afficher de la publicité.</p>
    <h2>Cookies utilisés sur ce site</h2>
    <ul><li><strong>Cookies nécessaires :</strong> ce site n'en dépose pas pour son fonctionnement courant. Votre choix de consentement est mémorisé dans le stockage local de votre navigateur.</li><li><strong>Mesure d'audience :</strong> aucune actuellement.</li><li><strong>Publicité :</strong> aucune.</li></ul>
    <h2>Votre consentement</h2><p>Si des cookies de mesure d'audience ou de publicité sont ajoutés, ils ne seront déposés qu'après votre accord explicite. Vous pouvez refuser aussi facilement que vous acceptez, et modifier votre choix à tout moment avec le lien « Gérer mes cookies » en bas de page.</p>
    <p><button class="btn btn-g" type="button" data-ck-open style="margin-top:.6rem">Modifier mon choix</button></p>
    <h2>Outils à déclarer avant ajout</h2><p>Avant d'installer un outil de mesure ou de publicité, liste à tenir à jour ici : ${TODO}</p>` },
  'cgv': { t: 'Conditions générales de vente', h: () => `
    <h2>1. Vendeur</h2><p>YANS, ${f('statut')}, représenté par ${f('responsable')}, ${f('adresse')}, SIRET ${f('siret')}. Contact : ${mail()}.</p>
    <h2>2. Description des prestations</h2><p>YANS conçoit des sites web pour coachs sportifs selon quatre offres : START, PRO, PREMIUM et ULTIMATE. Le contenu de chaque offre est celui affiché sur le site. Le devis accepté précise la prestation commandée.</p>
    <h2>3. Prix et modalités de paiement</h2><p>Les prix sont indiqués en euros : START 44,99 €, PRO 74,99 €, PREMIUM 99,99 €, ULTIMATE 124,99 €. Régime de TVA : ${f('tva')}. Modalités de paiement (moyens, échéances, acompte éventuel) : ${TODO}. Tout élément non listé dans l'offre (hébergement, nom de domaine, option) est indiqué dans le devis.</p>
    <h2>4. Délais de livraison</h2><p>Le délai est indiqué dans le devis. Il court à compter de la validation du devis et de la réception des contenus nécessaires (textes, photos, logo). Délai standard : ${TODO}</p>
    <h2>5. Modifications et retouches</h2><p>Le nombre de retouches incluses avant livraison est : ${TODO}. Toute modification supplémentaire ou postérieure à la livraison fait l'objet d'un accord préalable et, le cas échéant, d'un devis.</p>
    <h2>6. Propriété intellectuelle</h2><p>Le client garantit détenir les droits sur les contenus qu'il fournit. Les droits d'utilisation du site livré sont cédés au client après paiement intégral. Conditions précises de cession et droit de YANS à présenter le projet dans son portfolio : ${TODO}</p>
    <h2>7. Responsabilité</h2><p>YANS est tenue d'une obligation de moyens. Sa responsabilité ne peut être engagée pour les contenus fournis par le client, ni pour les interruptions dues à des tiers (hébergeur, registrar, réseau). Plafond et exclusions à définir : ${TODO}</p>
    <h2>8. Résiliation</h2><p>Chaque partie peut résilier la commande en cas de manquement de l'autre, après mise en demeure restée sans effet. Conditions en cas d'annulation par le client, et sort des sommes déjà versées : ${TODO}</p>
    <h2>9. Droit de rétractation</h2><p>Si le client est un consommateur, il dispose en principe d'un délai de 14 jours pour se rétracter d'un contrat conclu à distance. Exceptions possibles : prestation pleinement exécutée avant la fin du délai avec l'accord exprès du client et renonciation à son droit, et bien ou service réalisé selon les spécifications du client ou nettement personnalisé (article L221-28 du Code de la consommation). Le client professionnel agissant dans le cadre de son activité n'en bénéficie en principe pas, sauf cas prévus par la loi. À faire vérifier : ${TODO}</p>
    <h2>10. Médiation et droit applicable</h2><p>Les CGV sont soumises au droit français. En cas de litige avec un consommateur, un médiateur de la consommation peut être saisi : ${f('mediateur')}.</p>
    <h2>11. Coordonnées du vendeur</h2><p>${f('responsable')} — ${f('adresse')} — ${mail()}</p>` },
  'cgu': { t: "Conditions générales d'utilisation", h: () => `
    <h2>1. Objet</h2><p>Les présentes conditions encadrent l'utilisation du site YANS. En naviguant sur le site, vous les acceptez.</p>
    <h2>2. Accès au site</h2><p>Le site est accessible gratuitement. YANS s'efforce de le maintenir disponible, sans garantie d'accès continu, et peut l'interrompre pour maintenance ou évolution.</p>
    <h2>3. Utilisation du formulaire</h2><p>Les informations saisies doivent être exactes. Il est interdit d'utiliser le formulaire pour envoyer des contenus illicites, trompeurs ou abusifs.</p>
    <h2>4. Propriété intellectuelle</h2><p>Les contenus du site sont protégés. Toute reproduction sans autorisation écrite est interdite.</p>
    <h2>5. Démonstrations</h2><p>Les maquettes sont fictives et fournies à titre d'illustration. Elles n'engagent pas YANS sur un résultat identique pour un projet réel.</p>
    <h2>6. Responsabilité</h2><p>YANS ne peut être tenue responsable des dommages liés à l'utilisation du site ou à l'indisponibilité d'un service tiers. Les liens vers des sites externes n'engagent pas YANS sur leur contenu.</p>
    <h2>7. Données personnelles</h2><p>Voir la <a href="#confidentialite">politique de confidentialité</a>.</p>
    <h2>8. Modification et droit applicable</h2><p>YANS peut modifier ces conditions à tout moment. Elles sont soumises au droit français. Tribunal compétent : ${TODO}</p>` }
};
const ORDER = Object.keys(PAGES);

function renderLegal(id){
  const p = PAGES[id];
  $('#legal-in').innerHTML = `<a class="back" href="#accueil">← Retour à l'accueil</a><h1>${p.t}</h1>
    <nav class="legal-nav" aria-label="Pages légales">${ORDER.map(k => `<a href="#${k}"${k === id ? ' aria-current="page"' : ''}>${PAGES[k].t}</a>`).join('')}</nav>
    ${DRAFT}<article>${p.h()}</article>`;
}

/* Routage par ancre */
function route(){
  const id = location.hash.slice(1);
  if (PAGES[id]) {
    renderLegal(id);
    $('#home').hidden = true; $('#legal').hidden = false;
    window.scrollTo(0, 0);
  } else {
    const wasLegal = !$('#legal').hidden;
    $('#legal').hidden = true; $('#home').hidden = false;
    const el = id && document.getElementById(id);
    if (el) el.scrollIntoView({ block: 'start' });
    else if (wasLegal) window.scrollTo(0, 0);
  }
}
addEventListener('hashchange', route);

/* Révélations au scroll : visibles au repos, animées seulement si hors écran */
(function(){
  if (!('IntersectionObserver' in window) || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.remove('pre'); io.unobserve(e.target); } }), { threshold: .12 });
  $$('.rv').forEach(el => { if (el.getBoundingClientRect().top > innerHeight) { el.classList.add('pre'); io.observe(el); } });
})();

/* Halo des cartes */
$$('.card').forEach(c => c.addEventListener('pointermove', e => { const r = c.getBoundingClientRect(); c.style.setProperty('--mx', (e.clientX - r.left) + 'px'); c.style.setProperty('--my', (e.clientY - r.top) + 'px'); }));

/* Choix d'une offre */
$$('[data-offer]').forEach(a => a.addEventListener('click', () => {
  const sel = $('#f-offre'); const o = [...sel.options].find(o => o.text.startsWith(a.dataset.offer));
  if (o) sel.value = o.text;
}));

/* Formulaire */
const form = $('#form'), result = $('#result');
const setErr = (id, msg) => { $('#e-' + id).textContent = msg || ''; const inp = $('#f-' + id); if (inp) inp.setAttribute('aria-invalid', msg ? 'true' : 'false'); return !msg; };
function validate(){
  const v = k => form.elements[k].value.trim();
  const checks = [
    setErr('prenom', v('prenom').length < 2 ? 'Indiquez votre prénom.' : ''),
    setErr('nom', v('nom').length < 2 ? 'Indiquez votre nom.' : ''),
    setErr('email', !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v('email')) ? 'Indiquez une adresse e-mail valide.' : ''),
    setErr('offre', !v('offre') ? 'Choisissez une offre.' : ''),
    setErr('desc', v('desc').length < 20 ? 'Décrivez votre projet en quelques phrases (20 caractères minimum).' : ''),
    setErr('consent', !form.elements.consent.checked ? 'Votre accord est nécessaire pour traiter votre demande.' : '')
  ];
  return checks.every(Boolean);
}
form.addEventListener('input', e => { if (e.target.id && $('#e-' + e.target.id.slice(2))?.textContent) validate(); });
form.addEventListener('submit', e => {
  e.preventDefault();
  if (!validate()) { const bad = $('[aria-invalid="true"]', form); bad && bad.focus(); return; }
  const v = k => form.elements[k].value.trim();
  const text = `Demande de devis YANS\n\nNom : ${v('prenom')} ${v('nom')}\nE-mail : ${v('email')}\nOffre souhaitée : ${v('offre')}\n\nProjet :\n${v('desc')}`;
  const to = CONFIG.email ? `<p>Envoyez-la à <strong>${esc(CONFIG.email)}</strong> : <a href="mailto:${esc(CONFIG.email)}?subject=${encodeURIComponent('Demande de devis YANS')}&body=${encodeURIComponent(text)}">ouvrir mon application e-mail</a>.</p>` : `<p>L'adresse e-mail professionnelle de YANS n'est pas encore renseignée sur ce site.</p>`;
  result.innerHTML = `<div class="ok">Demande prête</div><p>Votre demande est rédigée ci-dessous. Elle n'a pas été envoyée automatiquement.</p>${to}<textarea id="r-text" readonly aria-label="Récapitulatif de votre demande"></textarea><div class="cta" style="margin:0"><button class="btn btn-o" type="button" id="r-copy">Copier ma demande</button><button class="btn btn-g" type="button" id="r-back">Modifier</button></div>`;
  $('#r-text').value = text;
  form.hidden = true; result.hidden = false;
  $('#r-copy').addEventListener('click', async () => {
    const b = $('#r-copy');
    try { await navigator.clipboard.writeText(text); b.textContent = 'Copié'; }
    catch (_) { $('#r-text').select(); b.textContent = 'Texte sélectionné'; }
  });
  $('#r-back').addEventListener('click', () => { result.hidden = true; form.hidden = false; });
});

/* Consentement aux cookies : aucun outil non essentiel n'est chargé tant que consentAllows() est faux */
const CK = 'yans-consent';
const getConsent = () => { try { return JSON.parse(localStorage.getItem(CK)); } catch (_) { return null; } };
const setConsent = v => { try { localStorage.setItem(CK, JSON.stringify(v)); } catch (_) {} };
window.consentAllows = cat => { const c = getConsent(); return !!(c && c[cat]); }; // ex. if (consentAllows('analytics')) { /* charger l'outil */ }
const ck = $('#ck');
const closeCk = v => { setConsent({ analytics: v, ads: v, date: new Date().toISOString().slice(0, 10) }); ck.hidden = true; };
$('#ck-yes').addEventListener('click', () => closeCk(true));
$('#ck-no').addEventListener('click', () => closeCk(false));
document.addEventListener('click', e => { if (e.target.closest('#ck-open,[data-ck-open]')) ck.hidden = false; });
if (!getConsent()) ck.hidden = false;

route();
